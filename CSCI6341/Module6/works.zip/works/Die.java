
public class Die {

    public int roll ()
    {
	return RandTool.uniform (1, 6);
    }

}
