
public class RandTest {


    public static void main (String[] argv)
    {
        for (int i=0;i<10;i++){
            System.out.println(RandTool.uniform(0,10));
        }
    }


}

