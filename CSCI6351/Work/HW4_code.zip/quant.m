function inhat = quant(in,min,max,level)
%QUANT Summary of this function goes here
%   Detailed explanation goes here
vsize = size(in,1);
hsize = size(in,2);
max
min
sep = [min:(max-min)/level:max-1];
codebook = sep + (max - min)/level/2
sep = sep(2:level)
tmp = reshape(in, 1, []);
[index,quantized] = quantiz(tmp,sep,codebook);
inhat = reshape(quantized,vsize,hsize);
end