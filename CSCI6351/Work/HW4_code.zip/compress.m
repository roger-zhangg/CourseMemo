function [Ghat,dGhat,dG] = compress(image,N)
    % resize
    G = preprocess(image,N);
    % apply dct
    dG = blockproc(G,[N N],@(blkStruct) dct2(blkStruct.data));
    % split each term
    dterm = blockproc(dG,[N N],@(blkStruct) (getsplit(blkStruct.data,N,0)));
    ac1 = blockproc(dG,[N N],@(blkStruct) (getsplit(blkStruct.data,N,1)));
    ac2 = blockproc(dG,[N N],@(blkStruct) (getsplit(blkStruct.data,N,2)));
    
    % get min,max dc term
    dc_min = floor(min(min(dterm)));
    dc_max = ceil(max(max(dterm)));

    % get min,max ac term
    ac_only = blockproc(dG,[N N],@(blkStruct) removedc(blkStruct.data));
    ac_min = floor(min(min(ac_only)));
    ac_max = ceil(max(max(ac_only)));

    % quantize each term
    dterm_hat = quant(dterm,double(dc_min),double(dc_max),8);
    ac1_hat = quant(ac1,double(ac_min),double(ac_max),4);
    ac2_hat = quant(ac2,double(ac_min),double(ac_max),2);
   

    % reconstruct
    dGhat = reconstruct(dterm_hat,ac1_hat,ac2_hat,N);
    Ghat = blockproc(dGhat,[N N],@(blkStruct) idct2(blkStruct.data));

    % calc snr
    img_snr = snr(double(G),double(G)-Ghat)

    % calc compress_ratio
    size_before = size(G,1)*size(G,2)*8;
    split_size = floor((N^2-1)/10);
    blocks = size(G,1)/N*size(G,2)/N;
    size_now = blocks * (1+split_size*4+split_size*2);
    compress_ratio = size_before/size_now
    % show img
    imagesc(Ghat); colormap(gray);
end