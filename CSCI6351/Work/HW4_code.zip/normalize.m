function out = normalize(in,N,part)
%NORMALIZE Summary of this function goes here
%   Detailed explanation goes here
    split = floor((N^2-1)/10);
    out = zeros(1,N^2);
switch part
    case 0
        out(1)=in;
    case 1
        out(2:split+1)=in;
    case 2
        out(split+2:2*split+1) = in;
end