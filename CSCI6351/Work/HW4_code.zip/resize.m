function img = resize(in,N)
    vmax = size(in, 1)-mod(size(in, 1),N);
    hmax = size(in, 2)-mod(size(in, 2),N);
    img= in(1:vmax,1:hmax);
end