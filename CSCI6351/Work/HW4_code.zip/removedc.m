function out = removedc(in)
  out = in;
  out(1,1) = 0;
end