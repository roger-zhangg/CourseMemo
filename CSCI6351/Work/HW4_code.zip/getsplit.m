function out = getsplit(in,N,part)
%GETSPLIT Summary of this function goes here
%   Detailed explanation goes here
split = floor((N^2-1)/10);
z = zigzag(in);
dterm = z(1);
ac1 = z(2:split+1);
ac2 = z(split+2:split*2+1);
switch part
    case 0
        out=dterm;
    case 1
        out=ac1;
    case 2
        out =ac2;
end