function out = preprocess(file,N)
%PREPROCESS Summary of this function goes here
%   Detailed explanation goes here
[I,map]=imread(file); % or imread('image', 'format'); % format can be gif, tiff, etc.
G=ind2gray(I,map);
out = resize(G,N);
end