function dhat = reconstruct(dterm,ac1,ac2,N)
%RECONSTRUCT Summary of this function goes here
%   Detailed explanation goes here
    split = floor((N^2-1)/10);
    rdterm = blockproc(dterm,[1 1],@(blkStruct) [normalize(blkStruct.data,N,0)]);
    rac1 = blockproc(ac1,[1 split],@(blkStruct) [normalize(blkStruct.data,N,1)]);
    rac2 = blockproc(ac2,[1 split],@(blkStruct) [normalize(blkStruct.data,N,2)]);
    combine = rdterm + rac1+ rac2;
    dhat = blockproc(combine,[1 N^2],@(blkStruct) [izigzag(blkStruct.data,N,N)]);
end