SET SERVEROUTPUT ON

BEGIN
 greet('Nancy');
END;