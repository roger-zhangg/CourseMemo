SELECT COUNT(commission_pct)
FROM   employees
WHERE  department_id = 50;

