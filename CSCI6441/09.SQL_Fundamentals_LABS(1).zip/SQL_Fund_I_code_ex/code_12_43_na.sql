CREATE PUBLIC SYNONYM  dept
FOR    alice.departments;
