SELECT department_id, location_id
FROM   departments;