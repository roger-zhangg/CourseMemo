SELECT last_name, department_id
FROM   copy_emp;
