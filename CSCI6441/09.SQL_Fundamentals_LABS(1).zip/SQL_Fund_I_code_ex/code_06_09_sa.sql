SELECT COUNT(*)
FROM   employees
WHERE  department_id = 50;

