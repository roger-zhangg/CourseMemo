SELECT last_name, department_id, salary
FROM   employees
ORDER BY department_id, salary DESC;
