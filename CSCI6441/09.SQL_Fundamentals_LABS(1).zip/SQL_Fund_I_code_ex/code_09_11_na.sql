SELECT * FROM job_history;
