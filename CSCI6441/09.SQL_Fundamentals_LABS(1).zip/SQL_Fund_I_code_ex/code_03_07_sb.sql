SELECT last_name
FROM   employees
WHERE  hire_date = '17-FEB-96' ;
