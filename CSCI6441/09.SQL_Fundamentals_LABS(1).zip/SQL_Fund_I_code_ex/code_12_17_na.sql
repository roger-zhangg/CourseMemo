UPDATE empvu20
SET    department_id = 10
WHERE  employee_id = 201;