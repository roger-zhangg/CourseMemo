SELECT location_id, department_id
FROM   departments;