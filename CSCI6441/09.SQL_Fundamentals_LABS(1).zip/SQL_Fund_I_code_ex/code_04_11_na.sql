SELECT 'The job id for '||UPPER(last_name)||' is '
               ||LOWER(job_id) AS "EMPLOYEE DETAILS"
FROM   employees;