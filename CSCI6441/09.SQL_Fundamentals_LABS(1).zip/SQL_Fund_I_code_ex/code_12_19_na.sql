DELETE FROM empvu10
WHERE  employee_number = 200;
