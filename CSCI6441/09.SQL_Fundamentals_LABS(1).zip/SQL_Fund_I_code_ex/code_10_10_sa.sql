INSERT INTO employees
VALUES      (114, 
             'Den', 'Raphealy', 
             'DRAPHEAL', '515.127.4561',
             TO_DATE('FEB 3, 1999', 'MON DD, YYYY'),
             'SA_REP', 11000, 0.2, 100, 60);
