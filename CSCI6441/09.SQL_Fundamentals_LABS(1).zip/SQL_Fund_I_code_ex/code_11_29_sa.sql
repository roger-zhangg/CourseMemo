UPDATE employees
SET    department_id = 55
WHERE  department_id = 110;
