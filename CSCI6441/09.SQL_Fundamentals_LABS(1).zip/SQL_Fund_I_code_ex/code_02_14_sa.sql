SELECT last_name, job_id, salary, commission_pct
FROM   employees;