DROP SEQUENCE dept_deptid_seq;
