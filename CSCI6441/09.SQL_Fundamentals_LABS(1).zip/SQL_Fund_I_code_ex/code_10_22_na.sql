SELECT  *
FROM    departments
WHERE   department_name = 'Finance';