INSERT INTO departments 
           (department_id, department_name, location_id)
VALUES     (&department_id, '&department_name',&location);
