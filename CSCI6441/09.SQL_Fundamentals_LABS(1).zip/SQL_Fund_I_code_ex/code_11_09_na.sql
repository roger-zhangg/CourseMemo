INSERT INTO hire_dates values(45, NULL);
