DELETE FROM  departments
WHERE        department_id = 70;
