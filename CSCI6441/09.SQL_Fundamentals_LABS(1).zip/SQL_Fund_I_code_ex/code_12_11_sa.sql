SELECT *
FROM   salvu50;
