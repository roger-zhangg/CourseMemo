CREATE SYNONYM  d_sum
FOR  dept_sum_vu;
