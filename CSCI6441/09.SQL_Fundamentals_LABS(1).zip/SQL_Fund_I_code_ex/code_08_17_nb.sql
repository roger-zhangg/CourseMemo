SELECT last_name, salary, department_id
   FROM   employees
   WHERE  salary IN (2500, 4200, 4400, 6000, 7000, 8300, 8600, 17000);