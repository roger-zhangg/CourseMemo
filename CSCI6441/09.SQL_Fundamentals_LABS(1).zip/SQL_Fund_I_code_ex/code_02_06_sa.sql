SELECT *
FROM   departments;