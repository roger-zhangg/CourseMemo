DESCRIBE job_history
