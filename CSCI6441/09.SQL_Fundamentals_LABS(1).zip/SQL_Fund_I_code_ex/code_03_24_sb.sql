SELECT employee_id, last_name, salary*12 annsal
FROM   employees
ORDER BY annsal ;
