UPDATE employees
	SET job_id = 'IT_PROG', commission_pct = NULL	
	WHERE employee_id = 114;