INSERT INTO	departments (department_id, 
                          department_name    )
VALUES		(30, 'Purchasing');
