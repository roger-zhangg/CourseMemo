DROP INDEX emp_last_name_idx;
