DELETE FROM  employees WHERE employee_id = 114;
