SELECT employee_id, last_name, department_id
FROM   employees
WHERE  last_name = 'higgins';
