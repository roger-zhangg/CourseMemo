SELECT AVG(commission_pct)
FROM   employees;
