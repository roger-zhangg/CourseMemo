DESCRIBE dept50

SELECT   *
FROM     dept50;              
