SELECT DISTINCT job_id
FROM   employees;
