UPDATE  my_employee
SET     salary = 1000 
WHERE   salary < 900;
