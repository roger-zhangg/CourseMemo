SELECT  last_name, salary
FROM    employees 
WHERE   salary NOT BETWEEN 5000 AND 12000;
