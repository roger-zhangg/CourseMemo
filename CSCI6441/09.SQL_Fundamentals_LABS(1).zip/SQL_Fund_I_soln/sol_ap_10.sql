SELECT DISTINCT job_id
FROM   employees 
WHERE  department_id IN (10, 20);
