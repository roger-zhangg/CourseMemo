DESCRIBE dept;

