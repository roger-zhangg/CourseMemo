ALTER TABLE employees2 READ WRITE;

INSERT INTO employees2
VALUES (34, 'Grant','Marcie',5678,10);

