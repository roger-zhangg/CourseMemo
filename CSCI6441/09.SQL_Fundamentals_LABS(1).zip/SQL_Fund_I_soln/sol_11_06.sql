INSERT INTO employees2
VALUES (34, 'Grant','Marcie',5678,10)
