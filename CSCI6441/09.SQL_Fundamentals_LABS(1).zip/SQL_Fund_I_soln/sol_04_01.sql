SELECT  sysdate "Date"
FROM    dual;
