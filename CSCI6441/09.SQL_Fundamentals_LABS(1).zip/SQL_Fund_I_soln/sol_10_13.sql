DELETE
FROM  my_employee 
WHERE last_name = 'Dancs';
