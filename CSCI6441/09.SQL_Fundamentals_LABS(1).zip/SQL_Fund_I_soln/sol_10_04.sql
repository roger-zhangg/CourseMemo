INSERT INTO my_employee (id, last_name, first_name,                 
                         userid, salary)
  VALUES (2, 'Dancs', 'Betty', 'bdancs', 860);
