UPDATE   dept50
SET      deptno = 80
WHERE    employee = 'Matos';
