SELECT  * 
FROM    my_employee;     


