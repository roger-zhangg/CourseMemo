SELECT   employee, department_id 
FROM     employees_vu;
