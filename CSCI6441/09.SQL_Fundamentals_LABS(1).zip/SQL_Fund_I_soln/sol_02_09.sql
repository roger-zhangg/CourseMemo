SELECT last_name||', ' || job_id "Employee and Title"
FROM   employees;
