DESCRIBE my_employee
