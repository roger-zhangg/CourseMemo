SELECT last_name, salary, TRUNC(salary, -3)/1000  Thousands
FROM   employees;
