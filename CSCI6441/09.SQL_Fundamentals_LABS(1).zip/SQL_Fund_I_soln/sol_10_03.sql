INSERT INTO my_employee
  VALUES (1, 'Patel', 'Ralph', 'rpatel', 895);
