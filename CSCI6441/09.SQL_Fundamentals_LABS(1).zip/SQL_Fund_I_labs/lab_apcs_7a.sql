ALTER TABLE title
ADD  (price NUMBER(8,2));

DESCRIBE title
