-- Please add a valid schema in the update statement below.

UPDATE teach_a.departments
SET location_id = 1500
WHERE department_id = 20
/
