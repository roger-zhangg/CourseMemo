SELECT	department_name, last_name
FROM 	departments CROSS JOIN employees
/
