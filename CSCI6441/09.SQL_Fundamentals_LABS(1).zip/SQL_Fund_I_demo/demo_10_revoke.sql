-- Please add a valid user id in the revoke statement below.

REVOKE SELECT,UPDATE 
ON departments
FROM &db_user
/
