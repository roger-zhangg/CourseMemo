SELECT	department_id, department_name, location_id
FROM 	departments
WHERE	department_id in ( 10, 50 )
/
