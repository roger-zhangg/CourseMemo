SELECT	last_name, job_id, salary + commission_pct sal_and_comm
FROM	employees
/
